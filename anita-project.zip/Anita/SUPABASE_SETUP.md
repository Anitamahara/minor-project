# Supabase Integration Setup

## MCP Configuration
The MCP client has been configured to connect with your Supabase project at:
- Project Ref: `ksebauxqprpstdvmwwse`

## Local Setup

1. **Create environment file:**
   ```bash
   cp .env.example .env.local
   ```

2. **Update .env.local with your Supabase credentials:**
   ```env
   VITE_SUPABASE_URL=https://ksebauxqprpstdvmwwse.supabase.co
   VITE_SUPABASE_ANON_KEY=your-actual-anon-key-here
   ```

3. **Install dependencies:**
   ```bash
   yarn install
   ```

4. **Run the development server:**
   ```bash
   yarn dev
   ```

## Files Created

- `src/lib/supabase.ts` - Supabase client configuration
- `src/types/database.ts` - TypeScript types for your database
- `src/hooks/useSupabase.ts` - Custom hook for database operations
- `src/components/SupabaseExample.tsx` - Example component demonstrating usage
- `src/vite-env.d.ts` - Vite environment type definitions

## Usage

Visit `http://localhost:5173/supabase` to see the Supabase integration example.

## Database Schema

The example assumes a `users` table with the following structure:
```sql
create table users (
  id text primary key,
  email text not null,
  created_at timestamp with time zone default now()
);
```

## Next Steps

1. Get your actual anon key from Supabase dashboard
2. Update the .env.local file
3. Modify the database types in `src/types/database.ts` to match your actual schema
4. Use the `useSupabase` hook in your components
