-- Database Schema for Anita Project
-- Run these commands in your Supabase SQL Editor

-- Classrooms Table
CREATE TABLE classrooms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    section TEXT NOT NULL,
    room_number TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('Theory', 'Lab', 'Seminar')),
    status TEXT NOT NULL CHECK (status IN ('Available', 'Maintenance', 'Full')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Subjects Table
CREATE TABLE subjects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT NOT NULL UNIQUE,
    department TEXT NOT NULL CHECK (department IN ('Science', 'Arts', 'Commerce', 'Technology')),
    credits INTEGER NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Teachers Table
CREATE TABLE teachers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Teacher-Subject Relationship (Many-to-Many)
CREATE TABLE teacher_subjects (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    teacher_id TEXT NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(teacher_id, subject_id)
);

-- Students Table
CREATE TABLE students (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    classroom_id TEXT NOT NULL REFERENCES classrooms(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Notices Table
CREATE TABLE notices (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    date TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for better performance
CREATE INDEX idx_classrooms_status ON classrooms(status);
CREATE INDEX idx_classrooms_type ON classrooms(type);
CREATE INDEX idx_subjects_department ON subjects(department);
CREATE INDEX idx_subjects_code ON subjects(code);
CREATE INDEX idx_students_classroom_id ON students(classroom_id);
CREATE INDEX idx_notices_date ON notices(date);
CREATE INDEX idx_teacher_subjects_teacher_id ON teacher_subjects(teacher_id);
CREATE INDEX idx_teacher_subjects_subject_id ON teacher_subjects(subject_id);

-- Enable Row Level Security (RLS)
ALTER TABLE classrooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE teacher_subjects ENABLE ROW LEVEL SECURITY;

-- Allow all operations for now (you can restrict this later)
CREATE POLICY "Enable all operations on classrooms" ON classrooms FOR ALL USING (true);
CREATE POLICY "Enable all operations on subjects" ON subjects FOR ALL USING (true);
CREATE POLICY "Enable all operations on teachers" ON teachers FOR ALL USING (true);
CREATE POLICY "Enable all operations on students" ON students FOR ALL USING (true);
CREATE POLICY "Enable all operations on notices" ON notices FOR ALL USING (true);
CREATE POLICY "Enable all operations on teacher_subjects" ON teacher_subjects FOR ALL USING (true);
