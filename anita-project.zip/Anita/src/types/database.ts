export interface Database {
  public: {
    Tables: {
      classrooms: {
        Row: {
          id: string
          name: string
          section: string
          room_number: string
          capacity: number
          type: 'Theory' | 'Lab' | 'Seminar'
          status: 'Available' | 'Maintenance' | 'Full'
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          section: string
          room_number: string
          capacity: number
          type: 'Theory' | 'Lab' | 'Seminar'
          status: 'Available' | 'Maintenance' | 'Full'
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          section?: string
          room_number?: string
          capacity?: number
          type?: 'Theory' | 'Lab' | 'Seminar'
          status?: 'Available' | 'Maintenance' | 'Full'
          created_at?: string
          updated_at?: string
        }
      }
      subjects: {
        Row: {
          id: string
          name: string
          code: string
          department: 'Science' | 'Arts' | 'Commerce' | 'Technology'
          credits: number
          description: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          code: string
          department: 'Science' | 'Arts' | 'Commerce' | 'Technology'
          credits: number
          description?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          code?: string
          department?: 'Science' | 'Arts' | 'Commerce' | 'Technology'
          credits?: number
          description?: string
          created_at?: string
          updated_at?: string
        }
      }
      teachers: {
        Row: {
          id: string
          name: string
          email: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          email: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string
          created_at?: string
          updated_at?: string
        }
      }
      students: {
        Row: {
          id: string
          name: string
          email: string
          classroom_id: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          email: string
          classroom_id: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          email?: string
          classroom_id?: string
          created_at?: string
          updated_at?: string
        }
      }
      notices: {
        Row: {
          id: string
          title: string
          content: string
          date: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          content: string
          date: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          content?: string
          date?: string
          created_at?: string
          updated_at?: string
        }
      }
      teacher_subjects: {
        Row: {
          id: string
          teacher_id: string
          subject_id: string
          created_at: string
        }
        Insert: {
          id?: string
          teacher_id: string
          subject_id: string
          created_at?: string
        }
        Update: {
          id?: string
          teacher_id?: string
          subject_id?: string
          created_at?: string
        }
      }
    }
  }
}

// Export individual types for easier usage
export type Classroom = Database['public']['Tables']['classrooms']['Row'];
export type Subject = Database['public']['Tables']['subjects']['Row'];
export type Teacher = Database['public']['Tables']['teachers']['Row'];
export type Student = Database['public']['Tables']['students']['Row'];
export type Notice = Database['public']['Tables']['notices']['Row'];
export type TeacherSubject = Database['public']['Tables']['teacher_subjects']['Row'];
