import { useSupabase } from '../hooks/useSupabase'

export function SupabaseExample() {
  const { data, loading, error, insert } = useSupabase('teachers')

  const handleAddUser = async () => {
    try {
      await insert({
        name: `Teacher ${Date.now()}`,
        email: `teacher${Date.now()}@example.com`
      })
      window.location.reload() // Refresh to show new data
    } catch (err) {
      console.error('Error adding user:', err)
    }
  }

  if (loading) return <div>Loading...</div>
  if (error) return <div>Error: {error}</div>

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Supabase Integration Example</h2>
      
      <button
        onClick={handleAddUser}
        className="bg-blue-500 text-white px-4 py-2 rounded mb-4 hover:bg-blue-600"
      >
        Add Sample Teacher
      </button>

      <div className="space-y-2">
        <h3 className="text-lg font-semibold">Teachers:</h3>
        {data && data.length > 0 ? (
          data.map((teacher) => (
            <div key={teacher.id} className="p-3 border rounded">
              <p><strong>ID:</strong> {teacher.id}</p>
              <p><strong>Name:</strong> {teacher.name}</p>
              <p><strong>Email:</strong> {teacher.email}</p>
              <p><strong>Created:</strong> {new Date(teacher.created_at).toLocaleString()}</p>
            </div>
          ))
        ) : (
          <p>No teachers found. Click "Add Sample Teacher" to create one.</p>
        )}
      </div>
    </div>
  )
}
