import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import type { Database } from '../types/database'

type Tables = Database['public']['Tables']

export function useSupabase<T extends keyof Tables>(
  table: T,
  options?: {
    select?: string
    filter?: Record<string, any>
  }
) {
  const [data, setData] = useState<Tables[T]['Row'][] | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)
        let query = supabase
          .from(table as string)
          .select(options?.select || '*')

        if (options?.filter) {
          Object.entries(options.filter).forEach(([key, value]) => {
            query = query.eq(key, value)
          })
        }

        const { data: result, error } = await query

        if (error) throw error
        setData(result as unknown as Tables[T]['Row'][])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An error occurred')
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [table, options?.select, options?.filter])

  const insert = async (item: Tables[T]['Insert']) => {
    try {
      const { data: result, error } = await supabase
        .from(table as string)
        .insert(item)
        .select()

      if (error) throw error
      return result
    } catch (err) {
      throw err instanceof Error ? err.message : 'An error occurred'
    }
  }

  const update = async (id: string, updates: Tables[T]['Update']) => {
    try {
      const { data: result, error } = await supabase
        .from(table as string)
        .update(updates)
        .eq('id', id)
        .select()

      if (error) throw error
      return result
    } catch (err) {
      throw err instanceof Error ? err.message : 'An error occurred'
    }
  }

  const remove = async (id: string) => {
    try {
      const { error } = await supabase
        .from(table as string)
        .delete()
        .eq('id', id)

      if (error) throw error
      return true
    } catch (err) {
      throw err instanceof Error ? err.message : 'An error occurred'
    }
  }

  return { data, loading, error, insert, update, remove }
}
