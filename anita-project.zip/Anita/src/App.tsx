import { Navigate, Route, BrowserRouter as Router, Routes } from 'react-router-dom';
import { AdminLayout } from './components/layout/AdminLayout';
import { AuthProvider } from './context/AuthContext';
import { SupabaseDataProvider } from './context/SupabaseDataContext';
import { LoginPage } from './features/auth/LoginPage';
import { SignupPage } from './features/auth/SignupPage';
import { Dashboard } from './features/dashboard/Dashboard';
import {
  ClassroomManagement,
  NoticeManagement,
  SubjectManagement
} from './features/management/Entities';
import {
  StudentManagement,
  SubjectAssignment,
  TeacherManagement
} from './features/management/Users';
import { ProfilePage } from './features/profile/ProfilePage';
import { SettingsPage } from './features/settings/SettingsPage';
import { SupabaseExample } from './components/SupabaseExample';

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/signup" element={<SignupPage />} />

      <Route path="/" element={<AdminLayout />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="classrooms" element={<ClassroomManagement />} />
        <Route path="subjects" element={<SubjectManagement />} />
        <Route path="teachers" element={<TeacherManagement />} />
        <Route path="students" element={<StudentManagement />} />
        <Route path="notices" element={<NoticeManagement />} />
        <Route path="assignments" element={<SubjectAssignment />} />
        <Route path="supabase" element={<SupabaseExample />} />
        <Route path="profile" element={<ProfilePage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="*" element={<div className="p-8 text-center text-xl">404 - Page Not Found</div>} />
      </Route>
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <SupabaseDataProvider>
        <Router>
          <AppRoutes />
        </Router>
      </SupabaseDataProvider>
    </AuthProvider>
  );
}

export default App;
