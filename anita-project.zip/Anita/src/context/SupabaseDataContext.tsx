import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import type { Database } from '../types/database';

type Classroom = Database['public']['Tables']['classrooms']['Row'];
type Subject = Database['public']['Tables']['subjects']['Row'];
type Teacher = Database['public']['Tables']['teachers']['Row'];
type Student = Database['public']['Tables']['students']['Row'];
type Notice = Database['public']['Tables']['notices']['Row'];
type TeacherSubject = Database['public']['Tables']['teacher_subjects']['Row'];

interface DataContextType {
    classrooms: Classroom[];
    subjects: Subject[];
    teachers: Teacher[];
    students: Student[];
    notices: Notice[];
    teacherSubjects: TeacherSubject[];
    isLoading: boolean;

    addClassroom: (classroom: Omit<Classroom, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
    updateClassroom: (classroom: Classroom) => Promise<void>;
    deleteClassroom: (id: string) => Promise<void>;

    addSubject: (subject: Omit<Subject, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
    updateSubject: (subject: Subject) => Promise<void>;
    deleteSubject: (id: string) => Promise<void>;

    addTeacher: (teacher: Omit<Teacher, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
    updateTeacher: (teacher: Teacher) => Promise<void>;
    deleteTeacher: (id: string) => Promise<void>;

    addStudent: (student: Omit<Student, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
    updateStudent: (student: Student) => Promise<void>;
    deleteStudent: (id: string) => Promise<void>;

    addNotice: (notice: Omit<Notice, 'id' | 'created_at' | 'updated_at'>) => Promise<void>;
    updateNotice: (notice: Notice) => Promise<void>;
    deleteNotice: (id: string) => Promise<void>;

    addTeacherSubject: (teacherSubject: Omit<TeacherSubject, 'id' | 'created_at'>) => Promise<void>;
    deleteTeacherSubject: (id: string) => Promise<void>;

    refreshData: () => Promise<void>;
}

const SupabaseDataContext = createContext<DataContextType | undefined>(undefined);

export function SupabaseDataProvider({ children }: { children: React.ReactNode }) {
    const [classrooms, setClassrooms] = useState<Classroom[]>([]);
    const [subjects, setSubjects] = useState<Subject[]>([]);
    const [teachers, setTeachers] = useState<Teacher[]>([]);
    const [students, setStudents] = useState<Student[]>([]);
    const [notices, setNotices] = useState<Notice[]>([]);
    const [teacherSubjects, setTeacherSubjects] = useState<TeacherSubject[]>([]);
    const [isLoading, setIsLoading] = useState(true);

    // Load all data from Supabase
    const loadData = async () => {
        try {
            setIsLoading(true);

            const [
                { data: classroomsData, error: classroomsError },
                { data: subjectsData, error: subjectsError },
                { data: teachersData, error: teachersError },
                { data: studentsData, error: studentsError },
                { data: noticesData, error: noticesError },
                { data: teacherSubjectsData, error: teacherSubjectsError }
            ] = await Promise.all([
                supabase.from('classrooms').select('*'),
                supabase.from('subjects').select('*'),
                supabase.from('teachers').select('*'),
                supabase.from('students').select('*'),
                supabase.from('notices').select('*'),
                supabase.from('teacher_subjects').select('*')
            ]);

            if (classroomsError) throw classroomsError;
            if (subjectsError) throw subjectsError;
            if (teachersError) throw teachersError;
            if (studentsError) throw studentsError;
            if (noticesError) throw noticesError;
            if (teacherSubjectsError) throw teacherSubjectsError;

            setClassrooms(classroomsData || []);
            setSubjects(subjectsData || []);
            setTeachers(teachersData || []);
            setStudents(studentsData || []);
            setNotices(noticesData || []);
            setTeacherSubjects(teacherSubjectsData || []);

        } catch (error) {
            console.error('Error loading data:', error);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadData();
    }, []);

    // CRUD Operations
    const addClassroom = async (classroom: Omit<Classroom, 'id' | 'created_at' | 'updated_at'>) => {
        const { error } = await supabase.from('classrooms').insert([classroom]);
        if (error) throw error;
        await loadData();
    };

    const updateClassroom = async (classroom: Classroom) => {
        const { error } = await supabase
            .from('classrooms')
            .update(classroom)
            .eq('id', classroom.id);
        if (error) throw error;
        await loadData();
    };

    const deleteClassroom = async (id: string) => {
        const { error } = await supabase.from('classrooms').delete().eq('id', id);
        if (error) throw error;
        await loadData();
    };

    const addSubject = async (subject: Omit<Subject, 'id' | 'created_at' | 'updated_at'>) => {
        const { error } = await supabase.from('subjects').insert([subject]);
        if (error) throw error;
        await loadData();
    };

    const updateSubject = async (subject: Subject) => {
        const { error } = await supabase
            .from('subjects')
            .update(subject)
            .eq('id', subject.id);
        if (error) throw error;
        await loadData();
    };

    const deleteSubject = async (id: string) => {
        const { error } = await supabase.from('subjects').delete().eq('id', id);
        if (error) throw error;
        await loadData();
    };

    const addTeacher = async (teacher: Omit<Teacher, 'id' | 'created_at' | 'updated_at'>) => {
        const { error } = await supabase.from('teachers').insert([teacher]);
        if (error) throw error;
        await loadData();
    };

    const updateTeacher = async (teacher: Teacher) => {
        const { error } = await supabase
            .from('teachers')
            .update(teacher)
            .eq('id', teacher.id);
        if (error) throw error;
        await loadData();
    };

    const deleteTeacher = async (id: string) => {
        const { error } = await supabase.from('teachers').delete().eq('id', id);
        if (error) throw error;
        await loadData();
    };

    const addStudent = async (student: Omit<Student, 'id' | 'created_at' | 'updated_at'>) => {
        const { error } = await supabase.from('students').insert([student]);
        if (error) throw error;
        await loadData();
    };

    const updateStudent = async (student: Student) => {
        const { error } = await supabase
            .from('students')
            .update(student)
            .eq('id', student.id);
        if (error) throw error;
        await loadData();
    };

    const deleteStudent = async (id: string) => {
        const { error } = await supabase.from('students').delete().eq('id', id);
        if (error) throw error;
        await loadData();
    };

    const addNotice = async (notice: Omit<Notice, 'id' | 'created_at' | 'updated_at'>) => {
        const { error } = await supabase.from('notices').insert([notice]);
        if (error) throw error;
        await loadData();
    };

    const updateNotice = async (notice: Notice) => {
        const { error } = await supabase
            .from('notices')
            .update(notice)
            .eq('id', notice.id);
        if (error) throw error;
        await loadData();
    };

    const deleteNotice = async (id: string) => {
        const { error } = await supabase.from('notices').delete().eq('id', id);
        if (error) throw error;
        await loadData();
    };

    const addTeacherSubject = async (teacherSubject: Omit<TeacherSubject, 'id' | 'created_at'>) => {
        const { error } = await supabase.from('teacher_subjects').insert([teacherSubject]);
        if (error) throw error;
        await loadData();
    };

    const deleteTeacherSubject = async (id: string) => {
        const { error } = await supabase.from('teacher_subjects').delete().eq('id', id);
        if (error) throw error;
        await loadData();
    };

    const refreshData = async () => {
        await loadData();
    };

    if (isLoading) {
        return <div className="flex items-center justify-center min-h-screen">
            <div className="text-lg">Loading data from Supabase...</div>
        </div>;
    }

    return (
        <SupabaseDataContext.Provider value={{
            classrooms, subjects, teachers, students, notices, teacherSubjects,
            isLoading,
            addClassroom, updateClassroom, deleteClassroom,
            addSubject, updateSubject, deleteSubject,
            addTeacher, updateTeacher, deleteTeacher,
            addStudent, updateStudent, deleteStudent,
            addNotice, updateNotice, deleteNotice,
            addTeacherSubject, deleteTeacherSubject,
            refreshData
        }}>
            {children}
        </SupabaseDataContext.Provider>
    );
}

export function useSupabaseData() {
    const context = useContext(SupabaseDataContext);
    if (context === undefined) {
        throw new Error('useSupabaseData must be used within a SupabaseDataProvider');
    }
    return context;
}
