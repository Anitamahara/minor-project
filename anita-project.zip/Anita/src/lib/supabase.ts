import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://ksebauxqprpstdvmwwse.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtzZWJhdXhxcHJwc3Rkdm13d3NlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc5Njc3MDIsImV4cCI6MjA4MzU0MzcwMn0.ze_g3A3NdAVGp56q_dU75mo7o921HgwCTTdNp6K6FFY'

export const supabase = createClient(supabaseUrl, supabaseAnonKey)
