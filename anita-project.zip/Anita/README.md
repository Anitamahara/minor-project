# Anita Project - School Management System

A comprehensive school management system built with React, TypeScript, and Supabase.

## Features

- 🏫 **Classroom Management** - Manage classroom allocations and capacity
- 📚 **Subject Management** - Organize subjects by department with credit tracking
- 👨‍🏫 **Teacher Management** - Staff management with subject assignments
- 👨‍🎓 **Student Management** - Student enrollment and classroom assignments
- 📢 **Notice Board** - Centralized announcement system
- 📊 **Real-time Dashboard** - Overview of institutional metrics
- 🔐 **Authentication** - Secure user login and signup system

## Tech Stack

- **Frontend**: React 19.2.0, TypeScript 5.9.3, TailwindCSS 4.1.18
- **Backend**: Supabase 2.98.0 (PostgreSQL + Auth)
- **Build Tool**: Vite 7.2.4
- **Routing**: React Router 7.13.0
- **Icons**: Lucide React 0.563.0

## Quick Start

### Prerequisites
- Node.js 18+
- Supabase account

### Installation

1. Clone the repository
```bash
git clone https://github.com/Anitamahara/aanitaaa-project.git
cd aanitaaa-project
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
```bash
cp .env.example .env.local
```
Edit `.env.local` with your Supabase credentials:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

4. Set up database
   - Go to your Supabase project
   - Run the SQL commands in `database-schema.sql`
   - Run `npm run migrate` to populate with sample data

5. Start development server
```bash
npm run dev
```

## Database Schema

The application uses 6 main tables:
- `classrooms` - Physical classroom information
- `subjects` - Academic subjects and departments
- `teachers` - Teaching staff details
- `students` - Enrolled students
- `notices` - Institutional announcements
- `teacher_subjects` - Many-to-many relationship

## Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── auth/           # Authentication components
│   ├── layout/         # Layout components
│   └── ui/             # Base UI components
├── context/            # React contexts
│   ├── AuthContext.tsx
│   └── SupabaseDataContext.tsx
├── features/           # Feature modules
│   ├── auth/           # Authentication pages
│   ├── dashboard/      # Dashboard component
│   └── management/     # Entity management
├── hooks/              # Custom React hooks
├── lib/                # Utility libraries
└── types/              # TypeScript type definitions
```

## Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run migrate` - Migrate data to Supabase

## Deployment

The application is ready for deployment on Vercel, Netlify, or any static hosting service.

1. Build the application:
```bash
npm run build
```

2. Deploy the `dist` folder to your hosting provider

## Environment Variables

| Variable | Description |
|----------|-------------|
| `VITE_SUPABASE_URL` | Your Supabase project URL |
| `VITE_SUPABASE_ANON_KEY` | Your Supabase anonymous key |

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Commit and push to your branch
5. Open a pull request

## License

This project is licensed under the MIT License.
