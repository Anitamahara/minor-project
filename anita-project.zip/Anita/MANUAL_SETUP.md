# Manual Database Setup Guide

## Step 1: Create Tables in Supabase Dashboard

Go to your Supabase project: https://supabase.com/dashboard/project/ksebauxqprpstdvmwwse

Navigate to **SQL Editor** and run these commands one by one:

```sql
-- Create Classrooms Table
CREATE TABLE classrooms (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    section TEXT NOT NULL,
    room_number TEXT NOT NULL,
    capacity INTEGER NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('Theory', 'Lab', 'Seminar')),
    status TEXT NOT NULL CHECK (status IN ('Available', 'Maintenance', 'Full')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Subjects Table
CREATE TABLE subjects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT NOT NULL UNIQUE,
    department TEXT NOT NULL CHECK (department IN ('Science', 'Arts', 'Commerce', 'Technology')),
    credits INTEGER NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Teachers Table
CREATE TABLE teachers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Students Table
CREATE TABLE students (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    classroom_id TEXT NOT NULL REFERENCES classrooms(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Notices Table
CREATE TABLE notices (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    content TEXT NOT NULL,
    date TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create Teacher-Subjects Relationship Table
CREATE TABLE teacher_subjects (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid(),
    teacher_id TEXT NOT NULL REFERENCES teachers(id) ON DELETE CASCADE,
    subject_id TEXT NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(teacher_id, subject_id)
);

-- Enable Row Level Security
ALTER TABLE classrooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE teachers ENABLE ROW LEVEL SECURITY;
ALTER TABLE students ENABLE ROW LEVEL SECURITY;
ALTER TABLE notices ENABLE ROW LEVEL SECURITY;
ALTER TABLE teacher_subjects ENABLE ROW LEVEL SECURITY;

-- Allow all operations (you can restrict this later)
CREATE POLICY "Enable all operations on classrooms" ON classrooms FOR ALL USING (true);
CREATE POLICY "Enable all operations on subjects" ON subjects FOR ALL USING (true);
CREATE POLICY "Enable all operations on teachers" ON teachers FOR ALL USING (true);
CREATE POLICY "Enable all operations on students" ON students FOR ALL USING (true);
CREATE POLICY "Enable all operations on notices" ON notices FOR ALL USING (true);
CREATE POLICY "Enable all operations on teacher_subjects" ON teacher_subjects FOR ALL USING (true);
```

## Step 2: Migrate Sample Data

After creating tables, run these insert commands:

```sql
-- Insert Sample Classrooms
INSERT INTO classrooms (id, name, section, room_number, capacity, type, status) VALUES
('c-1', 'Civil Lab 1', 'E', '101', 24, 'Lab', 'Available'),
('c-2', 'BCT/BEL Block - 101', 'A', '102', 25, 'Theory', 'Available'),
('c-3', 'Computer Lab 1', 'B', '103', 26, 'Lab', 'Available'),
('c-4', 'Civil Block - 103', 'A', '104', 27, 'Theory', 'Maintenance'),
('c-5', 'BCT/BEL Block - 104', 'B', '105', 28, 'Seminar', 'Full');

-- Insert Sample Subjects
INSERT INTO subjects (id, name, code, department, credits, description) VALUES
('s-1', 'Object Oriented Programming', 'CT101', 'Technology', 4, 'C++ and Java based OOP concepts.'),
('s-2', 'Data Structures & Algorithms', 'CT102', 'Technology', 4, 'Fundamental algorithms and complexity analysis.'),
('s-3', 'Digital Logic', 'EX101', 'Technology', 3, 'Logic gates, flip-flops, and circuit design.'),
('s-4', 'Microprocessor', 'EX102', 'Technology', 4, '8085/8086 architecture and assembly.'),
('s-5', 'Database Management System', 'CT201', 'Technology', 3, 'SQL, normalization, and DB optimization.');

-- Insert Sample Teachers
INSERT INTO teachers (id, name, email) VALUES
('t-1', 'Ram Bahadur Thapa', 'ram.thapa@academia.edu.np'),
('t-2', 'Sumi Khadka', 'sumi.khadka@academia.edu.np'),
('t-3', 'Prabin Shrestha', 'prabin.shrestha@academia.edu.np');

-- Insert Teacher-Subject Relationships
INSERT INTO teacher_subjects (teacher_id, subject_id) VALUES
('t-1', 's-1'), ('t-1', 's-2'),
('t-2', 's-3'), ('t-2', 's-4'),
('t-3', 's-5'), ('t-3', 's-1');

-- Insert Sample Students
INSERT INTO students (id, name, email, classroom_id) VALUES
('st-1', 'Ram Shrestha', 'student.1@student.ioe.edu.np', 'c-1'),
('st-2', 'Sumi Karki', 'student.2@student.ioe.edu.np', 'c-2'),
('st-3', 'Prabin Paudel', 'student.3@student.ioe.edu.np', 'c-3');

-- Insert Sample Notices
INSERT INTO notices (id, title, content, date) VALUES
('n-1', 'Exam Schedule for Sem 1', 'Attention all students, this is to inform you about notice #1 which concerns the upcoming academic calendar and events.', '2025-02-28'),
('n-2', 'Workshop on Object Oriented Programming', 'Attention all students, this is to inform you about notice #2 which concerns the upcoming academic calendar and events.', '2025-02-27'),
('n-3', 'Exam Schedule for Sem 2', 'Attention all students, this is to inform you about notice #3 which concerns the upcoming academic calendar and events.', '2025-02-26');
```

## Step 3: Update Application

The application is already configured to use Supabase! After you complete the database setup:

1. **Restart your development server:**
   ```bash
   yarn dev
   ```

2. **Test the connection:**
   - Visit `http://localhost:5173/supabase` to test the basic connection
   - Navigate to `/classrooms`, `/subjects`, `/teachers`, `/students`, `/notices` to see data from database

## Step 4: Verify Everything Works

Your application now:
- ✅ Connects to Supabase database
- ✅ Uses real data instead of localStorage
- ✅ Supports full CRUD operations
- ✅ Has proper TypeScript types
- ✅ Maintains the same UI/UX

All data operations will now sync with your Supabase database in real-time!
