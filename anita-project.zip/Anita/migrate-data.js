// Migration Script - Run this with Node.js to populate Supabase
// Usage: node migrate-data.js

import { createClient } from '@supabase/supabase-js';

// Import your dummy data
import {
    classrooms,
    subjects,
    teachers,
    students,
    notices
} from './src/lib/dummy-data.js';

// Supabase configuration
const supabaseUrl = 'https://ksebauxqprpstdvmwwse.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtzZWJhdXhxcHJwc3Rkdm13d3NlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc5Njc3MDIsImV4cCI6MjA4MzU0MzcwMn0.ze_g3A3NdAVGp56q_dU75mo7o921HgwCTTdNp6K6FFY';

const supabase = createClient(supabaseUrl, supabaseKey);

async function migrateData() {
    console.log('Starting data migration...');

    try {
        // 1. Insert Classrooms
        console.log('Migrating classrooms...');
        const { data: classroomsData, error: classroomsError } = await supabase
            .from('classrooms')
            .upsert(classrooms.map(c => ({
                id: c.id,
                name: c.name,
                section: c.section,
                room_number: c.roomNumber,
                capacity: c.capacity,
                type: c.type,
                status: c.status
            })), { onConflict: 'id' });

        if (classroomsError) throw classroomsError;
        console.log(`✅ Migrated ${classroomsData?.length || 0} classrooms`);

        // 2. Insert Subjects
        console.log('Migrating subjects...');
        const { data: subjectsData, error: subjectsError } = await supabase
            .from('subjects')
            .upsert(subjects.map(s => ({
                id: s.id,
                name: s.name,
                code: s.code,
                department: s.department,
                credits: s.credits,
                description: s.description
            })), { onConflict: 'id' });

        if (subjectsError) throw subjectsError;
        console.log(`✅ Migrated ${subjectsData?.length || 0} subjects`);

        // 3. Insert Teachers
        console.log('Migrating teachers...');
        const { data: teachersData, error: teachersError } = await supabase
            .from('teachers')
            .upsert(teachers.map(t => ({
                id: t.id,
                name: t.name,
                email: t.email
            })), { onConflict: 'id' });

        if (teachersError) throw teachersError;
        console.log(`✅ Migrated ${teachersData?.length || 0} teachers`);

        // 4. Insert Teacher-Subject Relationships
        console.log('Migrating teacher-subject relationships...');
        const teacherSubjects = [];
        teachers.forEach(teacher => {
            teacher.subjects.forEach(subjectId => {
                teacherSubjects.push({
                    teacher_id: teacher.id,
                    subject_id: subjectId
                });
            });
        });

        const { data: teacherSubjectsData, error: teacherSubjectsError } = await supabase
            .from('teacher_subjects')
            .upsert(teacherSubjects, { onConflict: 'teacher_id,subject_id' });

        if (teacherSubjectsError) throw teacherSubjectsError;
        console.log(`✅ Migrated ${teacherSubjectsData?.length || 0} teacher-subject relationships`);

        // 5. Insert Students
        console.log('Migrating students...');
        const { data: studentsData, error: studentsError } = await supabase
            .from('students')
            .upsert(students.map(s => ({
                id: s.id,
                name: s.name,
                email: s.email,
                classroom_id: s.classroomId
            })), { onConflict: 'id' });

        if (studentsError) throw studentsError;
        console.log(`✅ Migrated ${studentsData?.length || 0} students`);

        // 6. Insert Notices
        console.log('Migrating notices...');
        const { data: noticesData, error: noticesError } = await supabase
            .from('notices')
            .upsert(notices.map(n => ({
                id: n.id,
                title: n.title,
                content: n.content,
                date: n.date
            })), { onConflict: 'id' });

        if (noticesError) throw noticesError;
        console.log(`✅ Migrated ${noticesData?.length || 0} notices`);

        console.log('\n🎉 Migration completed successfully!');
        console.log('\nSummary:');
        console.log(`- Classrooms: ${classroomsData?.length || 0}`);
        console.log(`- Subjects: ${subjectsData?.length || 0}`);
        console.log(`- Teachers: ${teachersData?.length || 0}`);
        console.log(`- Teacher-Subject Relationships: ${teacherSubjectsData?.length || 0}`);
        console.log(`- Students: ${studentsData?.length || 0}`);
        console.log(`- Notices: ${noticesData?.length || 0}`);

    } catch (error) {
        console.error('❌ Migration failed:', error);
        process.exit(1);
    }
}

// Run the migration
migrateData();
